export interface ScannerOptions {
    reader: boolean;
    microphone: boolean;
    sound: boolean;
  }
  