function odoo_cfg(){
    this.conexion = function(){
        var odoo_cfg = {
            url: '',
            db: '',
        }
        return odoo_cfg    
    }
}
